JAMA project: http://math.nist.gov/javanumerics/jama/

The JAMA project website contains the following copyright notice:

==============================================================
"Copyright Notice

This software is a cooperative product of The MathWorks and the National Institute of Standards and Technology (NIST) which has been released to the public domain. Neither The MathWorks nor NIST assumes any responsibility whatsoever for its use by other parties, and makes no guarantees, expressed or implied, about its quality, reliability, or any other characteristic."
==============================================================

The website goes on to state that:

"As Jama is in the public domain other developers are free to adopt and adapt this code to other styles of programming or to extend or modernize the API ... Make note, however, that NIST makes no endorsement of these projects"


Our Cholesky Decomposition code in infodynamics.utils.MatrixUtils was adapted from this source.


