#!/bin/bash
#
# Usage: runSample

java -classpath "../../../infodynamics.jar" infodynamics.networkinference.interregional.InterregionalChannelMeasure interregionalCalc.properties

